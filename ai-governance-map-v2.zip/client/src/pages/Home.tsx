import { useState, useMemo } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { BarChart3, Shield, TrendingUp, Activity, Search, Download, Settings, Menu, X } from 'lucide-react';

/**
 * Design Philosophy: Enterprise Dashboard Modernism
 * - Clean, information-dense layouts with generous whitespace
 * - Hierarchical typography with Geist display font
 * - Teal accent (#0891B2) for interactive elements
 * - Subtle depth through layered surfaces and soft shadows
 */

export default function Home() {
  const [, navigate] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTier, setSelectedTier] = useState('All');

  // Sample governance data
  const governanceControls = [
    {
      id: 1,
      name: 'AI Model Transparency',
      tier: 'Critical',
      status: 'Compliant',
      maturity: 4,
      frameworks: ['ISO 42001', 'EU AI Act'],
    },
    {
      id: 2,
      name: 'Data Privacy Controls',
      tier: 'Critical',
      status: 'In Progress',
      maturity: 3,
      frameworks: ['GDPR', 'CCPA'],
    },
    {
      id: 3,
      name: 'Bias Detection & Mitigation',
      tier: 'High',
      status: 'Compliant',
      maturity: 3,
      frameworks: ['ISO 42001', 'NIST AI RMF'],
    },
    {
      id: 4,
      name: 'Model Monitoring & Auditing',
      tier: 'High',
      status: 'Planning',
      maturity: 2,
      frameworks: ['NIST AI RMF', 'SOC 2'],
    },
    {
      id: 5,
      name: 'Incident Response Plan',
      tier: 'Medium',
      status: 'Compliant',
      maturity: 4,
      frameworks: ['ISO 27035', 'NIST Cybersecurity'],
    },
  ];

  const filteredControls = useMemo(() => {
    return governanceControls.filter(control => {
      const matchSearch = !searchTerm || control.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchTier = selectedTier === 'All' || control.tier === selectedTier;
      return matchSearch && matchTier;
    });
  }, [searchTerm, selectedTier]);

  const stats = [
    { label: 'Total Controls', value: '21', icon: Shield },
    { label: 'Compliant', value: '14', icon: Activity },
    { label: 'Frameworks', value: '27', icon: BarChart3 },
    { label: 'Maturity Score', value: '72%', icon: TrendingUp },
  ];

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'Critical':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'High':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Medium':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Compliant':
        return 'text-green-600';
      case 'In Progress':
        return 'text-blue-600';
      case 'Planning':
        return 'text-orange-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-card shadow-sm">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="rounded-lg p-2 hover:bg-secondary lg:hidden"
            >
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div>
              <h1 className="text-display-sm font-bold text-foreground">AI Governance Map</h1>
              <p className="text-body-sm text-muted-foreground">v2.0 · Enterprise Edition</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm">
              <Download size={16} className="mr-2" />
              Export
            </Button>
            <Button variant="ghost" size="sm">
              <Settings size={16} />
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        {sidebarOpen && (
          <aside className="hidden w-64 border-r border-border bg-card lg:block">
            <nav className="space-y-1 p-4">
              <NavItem icon={Shield} label="Controls" active />
              <NavItem icon={BarChart3} label="Analytics" onClick={() => navigate('/analytics')} />
              <NavItem icon={Activity} label="Gap Analysis" onClick={() => navigate('/gap-analysis')} />
              <NavItem icon={TrendingUp} label="Compliance Matrix" onClick={() => navigate('/compliance-matrix')} />
            </nav>
          </aside>
        )}

        {/* Main Content */}
        <main className="flex-1 p-6 lg:p-8">
          {/* Hero Section with Background */}
          <div
            className="mb-8 rounded-xl bg-cover bg-center p-8 text-white shadow-lg"
            style={{
              backgroundImage:
                'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663636277123/SLVWA7aXQr8mqWTV4aJYPN/hero-governance-dashboard-iQEzGCjGxCvpf8Cncz3UhQ.webp)',
              backgroundColor: '#0F172A',
            }}
          >
            <div className="max-w-2xl">
              <h2 className="mb-2 text-4xl font-bold">Governance at Scale</h2>
              <p className="text-lg opacity-90">
                Assess, monitor, and improve your AI governance posture across all frameworks and
                jurisdictions.
              </p>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="mb-8 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
            {stats.map((stat, idx) => {
              const Icon = stat.icon;
              return (
                <Card key={idx} className="border-border bg-card">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-body-sm text-muted-foreground">{stat.label}</p>
                        <p className="mt-2 text-3xl font-bold text-foreground">{stat.value}</p>
                      </div>
                      <Icon className="text-primary opacity-20" size={32} />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Tabs Section */}
          <Tabs defaultValue="controls" className="space-y-6">
            <TabsList className="grid w-full max-w-md grid-cols-2">
              <TabsTrigger value="controls">Controls</TabsTrigger>
              <TabsTrigger value="frameworks">Frameworks</TabsTrigger>
            </TabsList>

            <TabsContent value="controls" className="space-y-6">
              {/* Search and Filters */}
              <Card className="border-border bg-card">
                <CardContent className="pt-6">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-3 text-muted-foreground" size={18} />
                      <Input
                        placeholder="Search controls..."
                        className="pl-10"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <div className="flex gap-2">
                      {['All', 'Critical', 'High', 'Medium'].map((tier) => (
                        <Button
                          key={tier}
                          variant={selectedTier === tier ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setSelectedTier(tier)}
                        >
                          {tier}
                        </Button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Controls List */}
              <div className="space-y-4">
                {filteredControls.map((control) => (
                  <Card
                    key={control.id}
                    className="border-l-4 border-l-primary border-r border-b border-t border-border bg-card transition-all hover:shadow-md"
                  >
                    <CardContent className="pt-6">
                      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                        <div className="flex-1">
                          <div className="mb-2 flex flex-wrap items-center gap-2">
                            <h3 className="text-heading-md font-semibold text-foreground">
                              {control.name}
                            </h3>
                            <Badge className={getTierColor(control.tier)}>{control.tier}</Badge>
                            <Badge variant="outline" className={getStatusColor(control.status)}>
                              {control.status}
                            </Badge>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {control.frameworks.map((fw) => (
                              <Badge key={fw} variant="secondary" className="text-body-sm">
                                {fw}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex flex-col items-start gap-2 lg:items-end">
                          <div className="text-body-sm text-muted-foreground">Maturity Level</div>
                          <div className="flex gap-1">
                            {[1, 2, 3, 4, 5].map((level) => (
                              <div
                                key={level}
                                className={`h-2 w-6 rounded-sm ${
                                  level <= control.maturity ? 'bg-primary' : 'bg-secondary'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="frameworks" className="space-y-6">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle>Supported Frameworks</CardTitle>
                  <CardDescription>
                    Coverage across global compliance and governance standards
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
                    {[
                      'ISO 42001',
                      'EU AI Act',
                      'GDPR',
                      'CCPA',
                      'NIST AI RMF',
                      'SOC 2',
                      'ISO 27035',
                      'NIST Cybersecurity',
                    ].map((fw) => (
                      <button
                        key={fw}
                        onClick={() => navigate(`/frameworks/${fw.toLowerCase().replace(/\s+/g, '-')}`)}
                        className="rounded-lg border border-border bg-secondary p-3 transition-all hover:bg-primary hover:text-primary-foreground"
                      >
                        <p className="text-body-sm font-medium">{fw}</p>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}

interface NavItemProps {
  icon: React.ComponentType<{ size?: number }>;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

function NavItem({ icon: Icon, label, active = false, onClick }: NavItemProps) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-lg px-4 py-2 text-body-md transition-colors ${
        active
          ? 'bg-primary text-primary-foreground'
          : 'text-foreground hover:bg-secondary'
      }`}
    >
      <Icon size={18} />
      {label}
    </button>
  );
}
